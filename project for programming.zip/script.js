const myButton = document.getElementById("myButton");
myButton.addEventListener("click", function() {
    alert("I love you :^)");
});

